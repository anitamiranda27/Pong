<!-- Se empieza una sesión -->
<?php
session_start();
?>

<HTML>
   <HEAD>
      <TITLE>Pong</TITLE>


		Se ha producido un error con la conexión de la base de datos. Por favor, vuelva a intentarlo en unos instantes.



  <?php include 'parts/creditos.html';?>
   </BODY>
</HTML>
